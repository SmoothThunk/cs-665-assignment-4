/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerDataAdapterTest.java
 * Description: Class used to test different methods provided by the CustomerDataAdapter.
 */
package edu.bu.met.cs665.adapter;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import edu.bu.met.cs665.https.CustomerProfile_HTTPS;
import edu.bu.met.cs665.usb.CustomerDataImpl_USB;
import edu.bu.met.cs665.usb.CustomerProfile_USB;

public class CustomerDataAdapterTest {
	
	private CustomerDataImpl_USB customerData_USB;
	private CustomerDataAdapter customerDataAdapter;
	
	@Before
	public void setUp() throws Exception {
		customerData_USB = new CustomerDataImpl_USB();
		customerData_USB.addCustomer(new CustomerProfile_USB("Steven", 0));
		customerData_USB.addCustomer(new CustomerProfile_USB("Chris", 1));
		customerData_USB.addCustomer(new CustomerProfile_USB("Marco", 2));
		customerData_USB.addCustomer(new CustomerProfile_USB("Shelia", 3));
		customerData_USB.addCustomer(new CustomerProfile_USB("Michelle", 4));
		
		customerDataAdapter = new CustomerDataAdapter(customerData_USB);
	}

	@Test
	public void testPrintCustomer_Success() {
		customerDataAdapter.printCustomer(0);
		
		// printCustomer will set the customer of the given ID as active. 
		// This is checked to avoid having to check output stream directly.
		assertEquals(customerDataAdapter.getActiveCustomer(), new CustomerProfile_HTTPS("Steven", 0));
	}

	@Test
	public void testGetCustomer_USB_Success() {
		customerDataAdapter.getCustomer_USB(4);
		assertEquals(customerDataAdapter.getActiveCustomer(), new CustomerProfile_HTTPS("Michelle", 4));
	}

	@Test
	public void testGetActiveCustomer_Success() {
		Exception ex = assertThrows(NullPointerException.class, () -> {
			customerDataAdapter.getActiveCustomer();
		});
		
		assertEquals("Use getCustomer_USB or printCustomer, active customer is set after usage of either method", ex.getMessage()); 
	}

}
