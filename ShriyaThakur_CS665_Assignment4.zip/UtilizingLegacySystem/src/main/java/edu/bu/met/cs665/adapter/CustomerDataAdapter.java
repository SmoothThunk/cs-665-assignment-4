/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerDataAdapter.java
 * Description: Class used to bridge USB to HTTPS data.
 */
package edu.bu.met.cs665.adapter;

import edu.bu.met.cs665.https.CustomerDataImpl_HTTPS;
import edu.bu.met.cs665.https.CustomerProfile_HTTPS;
import edu.bu.met.cs665.usb.CustomerDataImpl_USB;
import edu.bu.met.cs665.usb.CustomerData_USB;
import edu.bu.met.cs665.usb.CustomerProfile_USB;

public class CustomerDataAdapter implements CustomerData_USB {
	
	private CustomerDataImpl_USB customerData_USB;
	private CustomerDataImpl_HTTPS customerData_HTTPS;
	private CustomerProfile_HTTPS customerProfile_HTTPS;
	
	public CustomerDataAdapter(CustomerDataImpl_USB customerData_USB) {
		this.customerData_USB = customerData_USB;
	}

	/**
	 * Internal method which will iterate through list of USB data and convert it to HTTPS.
	 * Sets to the adapter class.
	 */
	private void convertToHTTPS() {
		CustomerDataImpl_HTTPS convertedData = new CustomerDataImpl_HTTPS();
		for (CustomerProfile_USB profile : this.customerData_USB.accessData()) {
			convertedData.addCustomer(new CustomerProfile_HTTPS(profile.getCustomerName(), profile.getCustomerId()));
		}
		this.customerData_HTTPS = convertedData;
	}
	
	/**
	 * Converts USB data to HTTPS. Sets active customer. Prints customer profile. 
	 * @param customerId is ID of customer we wish to print profile of.
	 */
	@Override
	public void printCustomer(int customerId) {
		convertToHTTPS();
		this.customerData_HTTPS.getCustomer_HTTPS(customerId);
		this.customerProfile_HTTPS = this.customerData_HTTPS.getActiveCustomer_HTTPS();
		System.out.println(this.customerData_HTTPS.getActiveCustomer_HTTPS());
	}

	/**
	 * Converts USB data to HTTPS. Sets active customer. 
	 * @param customerId is ID of customer we wish to set as active.
	 */
	@Override
	public void getCustomer_USB(int customerId) {
		convertToHTTPS();
		this.customerData_HTTPS.getCustomer_HTTPS(customerId);
		this.customerProfile_HTTPS = this.customerData_HTTPS.getActiveCustomer_HTTPS();
	}
	
	/**
	 * Due to how adapter class is setup, we require this method to access the active customer. 
	 * The active customer is set by using getCustomer_USB or printCustomer. 
	 * @return customerProfile_HTTPS is active customer set based on the last method called. 
	 */
	public CustomerProfile_HTTPS getActiveCustomer() {
		if (customerProfile_HTTPS != null) {
			return this.customerProfile_HTTPS;
		} else {
			throw new NullPointerException("Use getCustomer_USB or printCustomer, active customer is set after usage of either method");
		}
	}

}
