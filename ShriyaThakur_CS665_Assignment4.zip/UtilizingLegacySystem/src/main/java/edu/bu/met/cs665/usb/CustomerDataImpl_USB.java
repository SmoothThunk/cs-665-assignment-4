/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerDataImpl_USB.java
 * Description: Implementation of USB data interface. 
 */
package edu.bu.met.cs665.usb;

import java.util.ArrayList;
import java.util.List;

public class CustomerDataImpl_USB implements CustomerData_USB {
	
	private List<CustomerProfile_USB> customerData_USB;
	private CustomerProfile_USB customerProfile_USB;

	public CustomerDataImpl_USB() {
		this.customerData_USB = new ArrayList<>();
	}
	
	public void addCustomer(CustomerProfile_USB customer) {
		this.customerData_USB.add(customer);
	}
	
	public void deleteCustomer(CustomerProfile_USB customer) {
		this.customerData_USB.remove(customer);
	}
	
	public List<CustomerProfile_USB> accessData() {
		return this.customerData_USB;
	}

	@Override
	public void printCustomer(int customerId) {
		System.out.print(this.customerData_USB.get(customerId).toString());
	}

	@Override
	public void getCustomer_USB(int customerId) {
		this.customerProfile_USB = customerData_USB.get(customerId);
	}
	
	public CustomerProfile_USB getActiveCustomer_USB() {
		return this.customerProfile_USB;
	}

}
