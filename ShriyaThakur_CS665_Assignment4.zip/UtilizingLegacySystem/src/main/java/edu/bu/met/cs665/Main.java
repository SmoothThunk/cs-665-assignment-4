/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: Main.java
 * Description: Main class for running application.
 */
package edu.bu.met.cs665;

import edu.bu.met.cs665.adapter.CustomerDataAdapter;
import edu.bu.met.cs665.usb.CustomerDataImpl_USB;
import edu.bu.met.cs665.usb.CustomerProfile_USB;

/**
 * This is the Main class.
 */
public class Main {

  /**
   * A main method to run examples.
   * You may use this method for development purposes as you start building your
   * assignments/final project.  This could prove convenient to test as you are developing.
   * However, please note that every assignment/final projects requires JUnit tests.
   */
  public static void main(String[] args) {

		CustomerDataImpl_USB customerData_USB;
		CustomerDataAdapter customerDataAdapter;

		// Note how each customer profile is of type USB.
		customerData_USB = new CustomerDataImpl_USB();
		customerData_USB.addCustomer(new CustomerProfile_USB("Steven", 0));
		customerData_USB.addCustomer(new CustomerProfile_USB("Chris", 1));
		customerData_USB.addCustomer(new CustomerProfile_USB("Marco", 2));
		customerData_USB.addCustomer(new CustomerProfile_USB("Shelia", 3));
		customerData_USB.addCustomer(new CustomerProfile_USB("Michelle", 4));

		// Takes USB data and converts to HTTPS.
		customerDataAdapter = new CustomerDataAdapter(customerData_USB);
		
		// Note how output customer profiles are of type HTTPS.
		customerDataAdapter.printCustomer(0);
		customerDataAdapter.printCustomer(1);
		customerDataAdapter.printCustomer(2);
		customerDataAdapter.printCustomer(3);
		customerDataAdapter.printCustomer(4);
	}

}
