/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerDataImpl_HTTPS.java
 * Description: Implementation of HTTPS data interface. 
 */
package edu.bu.met.cs665.https;

import java.util.ArrayList;
import java.util.List;

public class CustomerDataImpl_HTTPS implements CustomerData_HTTPS {
	
	private List<CustomerProfile_HTTPS> customerData_HTTPS;
	private CustomerProfile_HTTPS customerProfile_HTTPS;
	
	public CustomerDataImpl_HTTPS() {
		this.customerData_HTTPS = new ArrayList<>();
	}
	
	public void addCustomer(CustomerProfile_HTTPS customer) {
		customerData_HTTPS.add(customer);
	}
	
	public void deleteCustomer(CustomerProfile_HTTPS customer) {
		customerData_HTTPS.remove(customer);
	}

	@Override
	public void printCustomer(int customerId) {
		System.out.print(customerData_HTTPS.get(customerId).toString());
	}

	@Override
	public void getCustomer_HTTPS(int customerId) {
		this.customerProfile_HTTPS = customerData_HTTPS.get(customerId);
	}
	
	public CustomerProfile_HTTPS getActiveCustomer_HTTPS() {
		return this.customerProfile_HTTPS;
	}

}
