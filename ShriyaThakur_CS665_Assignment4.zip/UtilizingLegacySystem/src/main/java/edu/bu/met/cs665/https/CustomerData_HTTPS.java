/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerData_HTTPS.java
 * Description: Interface for HTTPS data. 
 */
package edu.bu.met.cs665.https;

public interface CustomerData_HTTPS {
	
	public void printCustomer(int customerId);
	public void getCustomer_HTTPS(int customerId);
}
