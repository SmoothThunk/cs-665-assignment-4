/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 11/07/2023
 * File Name: CustomerData_USB.java
 * Description: Interface for USB data. 
 */
package edu.bu.met.cs665.usb;

public interface CustomerData_USB {
	
	public void printCustomer(int customerId);
	public void getCustomer_USB(int customerId);
}
